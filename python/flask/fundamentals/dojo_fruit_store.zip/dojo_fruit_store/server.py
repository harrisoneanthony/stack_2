from flask import Flask, render_template, request, redirect
import datetime
app = Flask(__name__)  

@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['POST'])         
def checkout():
    data = {k:v for k,v in request.form.items()}
    total_fruit = int(data['strawberry']) + int(data['raspberry']) + int(data['apple'])
    current_time = datetime.datetime.now()
    date_and_time = str(current_time.month) + "/" + str(current_time.day) + "/" + str(current_time.year) + " " + str(current_time.hour) + ":" + str(current_time.minute) + ":" + str(current_time.second)
    return render_template("checkout.html", data=data, total_fruit=total_fruit, date_and_time = date_and_time)

@app.route('/fruits')         
def fruits():
    return render_template("fruits.html")

if __name__=="__main__":   
    app.run(debug=True, port=5001)    